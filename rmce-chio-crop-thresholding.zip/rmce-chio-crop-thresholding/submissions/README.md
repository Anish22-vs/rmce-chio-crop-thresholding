# Individual submissions
Each member keeps an individual copy of the deliverables in their own folder:

```
submissions/
  anish/    abdul/    babitha/    challa-sriya/
    weekly_diary.md   midterm_presentation.pptx   viva_notes.md   (any individual code changes)
```
Copy `docs/weekly_diary_template.md` into your folder and fill it in. Use your own branch if you edit shared code.
