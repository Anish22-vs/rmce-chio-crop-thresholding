# Method notes (simple language)

## 1. Why thresholding?
A crop image has leaf, soil, shadow, sky etc. Thresholds split gray levels into groups so each part becomes one class.
With `m` thresholds we get `m + 1` classes.

## 2. Minimum Cross Entropy (MCE)
Cross entropy tells how different the thresholded image is from the original. Best thresholds = smallest value.

For classes k = 1..m+1:
- w_k = sum of h(i) for gray levels i in class k  (zeroth moment = class probability)
- m_k = sum of i * h(i) for gray levels in class k (first moment)
- mean of class k: mu_k = m_k / w_k

Objective (constant term removed):  **eta(T) = - sum_k m_k * log(mu_k)**

Gray levels are numbered 1..256 (not 0..255) so that log(i) is defined.

## 3. "Recursive" part (R-MCE)
Instead of re-adding the histogram for every candidate, build the moments once:
- P(u) = P(u-1) + h(u)
- S(u) = S(u-1) + u * h(u)

Then for a class from level a to b:  w = P(b) - P(a-1),  m = S(b) - S(a-1).
Store the class cost for every (a, b) in one table H. Evaluating any set of thresholds is now `m + 1` table lookups.

### Small worked example (L = 4 gray levels, h = [0.1, 0.4, 0.3, 0.2], one threshold after level 2)
1. P = [0, 0.1, 0.5, 0.8, 1.0], S = [0, 0.1, 0.9, 1.8, 2.6]
2. Class 1 (levels 1-2): w = 0.5, m = 0.9, mu = 1.8, cost = -0.9 * ln(1.8) = -0.529
3. Class 2 (levels 3-4): w = 0.5, m = 1.7, mu = 3.4, cost = -1.7 * ln(3.4) = -2.080
4. eta = -0.529 + (-2.080) = **-2.609**. Try threshold after level 1 or 3 and keep the smaller eta.

## 4. CHIO (Coronavirus Herd Immunity Optimizer)
- Population = "cases". Each case = a vector of m thresholds. Status: susceptible (0), infected (1), immune (2).
- Start: C0 cases infected (1), rest susceptible.
- Each iteration, for each gene of a case, draw r in [0,1]:
  - r < BRr/3: move relative to a random infected case
  - r < 2*BRr/3: move relative to a random susceptible case
  - r < BRr: move relative to the best immune case
  - otherwise keep the gene (social distancing)
  - move rule: x_new = x + rand * (x - x_other)
- Keep the new case only if its objective is better.
- Status update: susceptible -> infected if worse than population mean and gene came from an infected case;
  infected -> immune if better than mean. Infected cases older than MaxAge die and are re-created randomly.
- Output: the best case = the best thresholds (rounded to integers, sorted).

Note: verify the status-update details against the original paper before the viva (see references.md).

## 5. Quality measures
- PSNR = 10 log10(255^2 / MSE) (higher = better)
- SSIM (closer to 1 = better)
