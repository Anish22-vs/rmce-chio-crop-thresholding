# Viva preparation - questions and short answers

1. **What is the aim of the project?** Segment crop images into regions by selecting optimal multilevel thresholds.
2. **What is thresholding / multilevel thresholding?** One threshold gives 2 classes; m thresholds give m+1 classes.
3. **Why cross entropy?** It measures information difference between original and segmented image; minimising it keeps the segmented image close to the original.
4. **What does "recursive" mean in R-MCE?** Zeroth and first order moments are computed recursively once and stored in a lookup table, so each objective evaluation is O(m), not O(L).
5. **Why start gray levels from 1?** log(0) is undefined.
6. **Why use an optimizer?** Exhaustive search needs about C(255, m) evaluations - too many for m >= 4.
7. **Explain CHIO.** Population-based, inspired by herd immunity: susceptible, infected, immune cases; BRr controls how often genes are changed; MaxAge removes old infected cases.
8. **Parameters of CHIO?** Population, iterations, C0, BRr, MaxAge.
9. **Why must the code explicitly implement R-MCE and CHIO?** The project title names both techniques; the code in `src/rmce_chio/mce.py` and `chio.py` implements them directly.
10. **How do you judge quality?** Objective value, PSNR, SSIM, run time, mean and std over multiple runs.
11. **Why many runs?** CHIO is stochastic; report mean +/- std.
12. **What happens as m increases?** PSNR/SSIM usually improve, run time increases.
13. **Python vs MATLAB?** Same algorithm in both; compare outputs for consistency.
14. **Limitations / future work?** Colour-channel (RGB) thresholding, other optimizers, larger crop dataset.
