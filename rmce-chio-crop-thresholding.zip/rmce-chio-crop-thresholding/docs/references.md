# References (check the exact details before citing)
- C. H. Li and C. K. Lee, "Minimum cross entropy thresholding," Pattern Recognition, 26(4), 1993.
- P.-Y. Yin, "Multilevel minimum cross entropy threshold selection based on particle swarm optimization," Applied Mathematics and Computation, 184(2), 2007 (recursive programming technique).
- M. A. Al-Betar, Z. A. A. Alyasseri, M. A. Awadallah, I. Abu Doush, "Coronavirus herd immunity optimizer (CHIO)," Neural Computing and Applications, 33, 2021.
