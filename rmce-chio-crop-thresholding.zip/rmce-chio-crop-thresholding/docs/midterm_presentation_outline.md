# Mid-term presentation outline (8-10 slides)
1. Title, team, mentor
2. Problem: segmentation of crop images
3. Thresholding basics (bi-level vs multilevel)
4. Minimum cross entropy objective
5. Recursive computation (moment tables) with the small worked example
6. CHIO algorithm (flowchart + parameters)
7. Implementation: Python + MATLAB pipeline
8. Results so far (segmented images, thresholds, PSNR / SSIM table)
9. Convergence plots
10. Next steps
