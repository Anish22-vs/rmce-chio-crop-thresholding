# Multilevel Thresholding of Crop Images using R-MCE and CHIO

Summer research internship project. We segment crop images into several intensity classes by choosing the best
thresholds with **Recursive Minimum Cross Entropy (R-MCE)** as the objective function and the
**Coronavirus Herd Immunity Optimizer (CHIO)** as the optimizer.

**Team:** Abdul, Anish, Babitha, Challa Sriya  **Mentor:** Dr. Arun Kumar Yadav

## Idea in 4 lines
1. Convert the crop image to gray and compute its histogram.
2. Pick `m` thresholds -> the image splits into `m+1` classes.
3. **R-MCE** gives a score (cross entropy between the original and the thresholded image). Lower is better.
   Moments are built recursively and stored in a lookup table, so each score is very fast.
4. **CHIO** searches for the thresholds with the lowest score (population of "cases": susceptible, infected, immune).

## Folder structure
```
src/rmce_chio/      Python code: mce.py (R-MCE), chio.py (CHIO), thresholding.py, metrics.py
matlab/             MATLAB version: rmce_table.m, rmce_objective.m, chio_optimize.m, main_demo.m
main.py             segment one image (saves segmented image, histogram plot, convergence plot)
run_experiments.py  batch runs over a folder -> CSV with mean/std of objective, PSNR, SSIM, time
tests/              pytest checks (table vs direct formula, CHIO vs exhaustive search)
notebooks/          Google Colab notebook
docs/               method notes, viva prep, weekly diary template, midterm outline, references
data/images/        put your crop images here (ignored by git)
outputs/            results are written here (ignored by git)
submissions/        individual copy of deliverables for each team member
```

## Run (Python)
```bash
pip install -r requirements.txt
python main.py                              # demo image
python main.py data/images/leaf.jpg --levels 2 3 4 5
python run_experiments.py data/images --levels 2 3 4 5 --runs 10
pytest -q
```
## Run (MATLAB)
Open `matlab/main_demo.m`, set your image file name, press Run. Needs Image Processing Toolbox.

## Parameters used (change in code or CLI)
Population size 30, iterations 100, BRr = 0.05, MaxAge = 100, C0 = 1, levels m = 2..5.

## Results
Fill this table after running on your crop images.

| Image | m | Thresholds | Objective | PSNR | SSIM | Time (s) |
|-------|---|------------|-----------|------|------|----------|
|       |   |            |           |      |      |          |

## Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit: R-MCE + CHIO crop image thresholding"
git branch -M main
git remote add origin https://github.com/<your-username>/rmce-chio-crop-thresholding.git
git push -u origin main
```
