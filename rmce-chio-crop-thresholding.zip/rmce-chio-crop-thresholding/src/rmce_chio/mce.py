"""Recursive Minimum Cross Entropy (R-MCE) objective for multilevel thresholding.

Gray levels are numbered 1..L (pixel intensity v -> level v+1) so that log(i) is defined.
Thresholds T_1 < ... < T_m are given as pixel intensities (0..L-2):
class k holds pixels with T_{k-1} < intensity <= T_k.

Objective (to MINIMISE), after dropping the constant term  sum_i i*h(i)*log(i):

    eta(T) = - sum_k  m_k * log( m_k / w_k )
    w_k = sum of h(i) in class k          (zeroth-order moment)
    m_k = sum of i*h(i) in class k        (first-order moment)

"Recursive" = the moments are built recursively
    P(u) = P(u-1) + h(u),   S(u) = S(u-1) + u*h(u)
and then every class cost H(lo, hi) is read from a lookup table, so one
evaluation of eta costs only O(m) instead of O(L).
"""
import numpy as np


class RMCE:
    def __init__(self, image, L=256):
        img = np.asarray(image)
        if img.dtype != np.uint8:
            raise ValueError("image must be uint8 (0-255)")
        self.L = L
        hist = np.bincount(img.ravel(), minlength=L).astype(float)
        self.h = hist / hist.sum()
        self._build_tables()

    def _build_tables(self):
        L, h = self.L, self.h
        P = np.zeros(L + 1)
        S = np.zeros(L + 1)
        for u in range(1, L + 1):              # recursive moment computation
            P[u] = P[u - 1] + h[u - 1]
            S[u] = S[u - 1] + u * h[u - 1]
        self.P, self.S = P, S
        # H[lo, hi] = cost of the class holding gray levels lo+1 .. hi
        w = P[None, :] - P[:, None]
        m = S[None, :] - S[:, None]
        with np.errstate(divide="ignore", invalid="ignore"):
            H = -m * np.log(m / w)
        H[~np.isfinite(H)] = 0.0               # empty classes contribute 0
        self.H = H

    def objective(self, thresholds):
        """Cross-entropy objective for thresholds given as pixel intensities."""
        t = np.sort(np.asarray(thresholds, dtype=int))
        if t.min() < 0 or t.max() > self.L - 2:
            return 1e9
        if np.any(np.diff(t) == 0):            # duplicate thresholds not allowed
            return 1e6 + float(np.sum(np.diff(t) == 0))
        edges = np.concatenate(([0], t + 1, [self.L]))
        return float(self.H[edges[:-1], edges[1:]].sum())

    def direct_objective(self, thresholds):
        """Slow textbook formula (for testing). Includes the constant term."""
        t = np.sort(np.asarray(thresholds, dtype=int))
        edges = np.concatenate(([0], t + 1, [self.L]))
        lv = np.arange(1, self.L + 1)
        total = 0.0
        for a, b in zip(edges[:-1], edges[1:]):
            lvls, hh = lv[a:b], self.h[a:b]
            m, w = (lvls * hh).sum(), hh.sum()
            if m > 0 and w > 0:
                mu = m / w
                nz = hh > 0
                total += (lvls[nz] * hh[nz] * np.log(lvls[nz] / mu)).sum()
        return total

    def constant_term(self):
        lv = np.arange(1, self.L + 1)
        nz = self.h > 0
        return float((lv[nz] * self.h[nz] * np.log(lv[nz])).sum())
