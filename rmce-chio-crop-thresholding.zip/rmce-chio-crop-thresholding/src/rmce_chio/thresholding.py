import numpy as np
from .mce import RMCE
from .chio import chio


def rmce_chio_threshold(image, m, hs=30, max_itr=100, br_r=0.05, max_age=100, seed=None):
    """Find m thresholds (pixel intensities) minimising R-MCE with CHIO.
    Returns (thresholds, best_objective, history)."""
    rmce = RMCE(image)
    obj = lambda x: rmce.objective(np.rint(x).astype(int))
    best, f, hist = chio(obj, m, 0, rmce.L - 2, hs=hs, max_itr=max_itr,
                         br_r=br_r, max_age=max_age, seed=seed)
    return np.sort(np.rint(best).astype(int)), f, hist


def apply_thresholds(image, thresholds):
    """Return (label_image, segmented_image). Each class is painted with its mean intensity."""
    t = np.sort(np.asarray(thresholds, dtype=int))
    labels = np.searchsorted(t, image.astype(int), side="left")  # intensity <= T_k -> class k
    seg = np.zeros_like(image, dtype=np.uint8)
    for k in range(len(t) + 1):
        mask = labels == k
        if mask.any():
            seg[mask] = np.uint8(round(image[mask].mean()))
    return labels, seg
