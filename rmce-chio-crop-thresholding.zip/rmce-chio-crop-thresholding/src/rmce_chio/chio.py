"""Coronavirus Herd Immunity Optimizer (CHIO) - minimisation version.

Population = "cases". Each case has a status: 0 susceptible, 1 infected, 2 immune.
Each gene of a new case is produced from one of the groups with probability
BRr/3 each (infected / susceptible / immune), otherwise it is copied unchanged
(social distancing moves AWAY from the chosen case).
Reference: Al-Betar, Alyasseri, Awadallah, Abu Doush (2021), Neural Computing and Applications.
"""
import numpy as np


def chio(objective, dim, lb, ub, hs=30, max_itr=100, c0=1,
         br_r=0.05, max_age=100, seed=None, stop_when_no_infected=False):
    rng = np.random.default_rng(seed)
    pop = rng.uniform(lb, ub, (hs, dim))
    fit = np.array([objective(x) for x in pop])
    status = np.zeros(hs, dtype=int)
    status[rng.choice(hs, size=c0, replace=False)] = 1
    age = np.zeros(hs, dtype=int)
    history = []

    for _ in range(max_itr):
        for i in range(hs):
            new = pop[i].copy()
            is_corona = False
            for j in range(dim):
                r = rng.random()
                if r < br_r / 3:                      # infected group
                    group = np.flatnonzero(status == 1)
                    if group.size:
                        c = rng.choice(group)
                        new[j] = pop[i, j] + rng.random() * (pop[i, j] - pop[c, j])
                        is_corona = True
                elif r < 2 * br_r / 3:                # susceptible group
                    group = np.flatnonzero(status == 0)
                    if group.size:
                        c = rng.choice(group)
                        new[j] = pop[i, j] + rng.random() * (pop[i, j] - pop[c, j])
                elif r < br_r:                        # immune group (best immune case)
                    group = np.flatnonzero(status == 2)
                    if group.size:
                        c = group[np.argmin(fit[group])]
                        new[j] = pop[i, j] + rng.random() * (pop[i, j] - pop[c, j])
            new = np.clip(new, lb, ub)
            f_new = objective(new)
            if f_new < fit[i]:
                pop[i], fit[i] = new, f_new
            mean_fit = fit.mean()
            # status update (minimisation: smaller fit = healthier)
            if status[i] == 0 and fit[i] > mean_fit and is_corona:
                status[i], age[i] = 1, 1
            elif status[i] == 1 and fit[i] <= mean_fit and is_corona:
                status[i] = 2
            if status[i] == 1:
                age[i] += 1
                if age[i] >= max_age:                  # case dies -> new random susceptible
                    pop[i] = rng.uniform(lb, ub, dim)
                    fit[i] = objective(pop[i])
                    status[i], age[i] = 0, 0
        history.append(fit.min())
        if stop_when_no_infected and not np.any(status == 1):
            break

    b = int(np.argmin(fit))
    return pop[b], float(fit[b]), history
