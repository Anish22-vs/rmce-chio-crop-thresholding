import numpy as np
from skimage.metrics import structural_similarity


def psnr(original, segmented):
    mse = np.mean((original.astype(float) - segmented.astype(float)) ** 2)
    return float("inf") if mse == 0 else 10 * np.log10(255.0 ** 2 / mse)


def ssim(original, segmented):
    return float(structural_similarity(original, segmented, data_range=255))
