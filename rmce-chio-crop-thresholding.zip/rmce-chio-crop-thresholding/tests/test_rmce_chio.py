import itertools, os, sys
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from rmce_chio import RMCE, rmce_chio_threshold, apply_thresholds


def synthetic_image(seed=0):
    rng = np.random.default_rng(seed)
    parts = [rng.normal(50, 8, 4000), rng.normal(120, 10, 4000), rng.normal(200, 9, 4000)]
    return np.clip(np.concatenate(parts), 0, 255).astype(np.uint8).reshape(120, 100)


def test_table_matches_direct_formula():
    img = synthetic_image()
    r = RMCE(img)
    c = r.constant_term()
    for T in ([85], [60, 150], [40, 100, 170], [30, 80, 130, 190]):
        assert abs(r.objective(T) + c - r.direct_objective(T)) < 1e-8


def test_chio_close_to_exhaustive_search_m2():
    img = synthetic_image()
    r = RMCE(img)
    best = min(r.objective(c) for c in itertools.combinations(range(1, 255), 2))
    T, f, _ = rmce_chio_threshold(img, 2, hs=30, max_itr=100, seed=1)
    assert abs(f - best) / abs(best) < 1e-3   # CHIO within 0.1% of the exhaustive optimum


def test_apply_thresholds_classes():
    img = synthetic_image()
    labels, seg = apply_thresholds(img, [85, 160])
    assert set(np.unique(labels)) == {0, 1, 2}
    assert len(np.unique(seg)) == 3
