"""Segment ONE crop image.   python main.py data/images/leaf.jpg --levels 2 3 4 5"""
import argparse, os, sys, time
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from skimage import io, color, img_as_ubyte, data

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))
from rmce_chio import rmce_chio_threshold, apply_thresholds, psnr, ssim


def load_gray(path):
    img = io.imread(path) if path else data.camera()
    if img.ndim == 3:
        img = color.rgb2gray(img[..., :3])
    return img_as_ubyte(img)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("image", nargs="?", help="path to image (default: demo image)")
    ap.add_argument("--levels", type=int, nargs="+", default=[2, 3, 4, 5])
    ap.add_argument("--pop", type=int, default=30)
    ap.add_argument("--iters", type=int, default=100)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="outputs")
    a = ap.parse_args()

    os.makedirs(a.out, exist_ok=True)
    gray = load_gray(a.image)
    name = os.path.splitext(os.path.basename(a.image))[0] if a.image else "demo"
    print(f"{'m':>2} {'thresholds':<28}{'objective':>12}{'PSNR':>8}{'SSIM':>8}{'time(s)':>9}")
    for m in a.levels:
        t0 = time.time()
        T, f, hist = rmce_chio_threshold(gray, m, hs=a.pop, max_itr=a.iters, seed=a.seed)
        dt = time.time() - t0
        _, seg = apply_thresholds(gray, T)
        print(f"{m:>2} {str(T.tolist()):<28}{f:>12.4f}{psnr(gray, seg):>8.2f}{ssim(gray, seg):>8.4f}{dt:>9.2f}")
        io.imsave(os.path.join(a.out, f"{name}_m{m}_segmented.png"), seg, check_contrast=False)
        fig, ax = plt.subplots(1, 3, figsize=(13, 3.5))
        ax[0].imshow(gray, cmap="gray"); ax[0].set_title("Original"); ax[0].axis("off")
        ax[1].imshow(seg, cmap="gray"); ax[1].set_title(f"Segmented (m={m})"); ax[1].axis("off")
        ax[2].hist(gray.ravel(), bins=256, range=(0, 255), color="gray")
        for t in T: ax[2].axvline(t, color="r")
        ax[2].set_title("Histogram + thresholds")
        fig.tight_layout(); fig.savefig(os.path.join(a.out, f"{name}_m{m}_summary.png"), dpi=150)
        plt.close(fig)
        plt.figure(figsize=(4, 3)); plt.plot(hist); plt.xlabel("iteration"); plt.ylabel("best objective")
        plt.title(f"CHIO convergence (m={m})"); plt.tight_layout()
        plt.savefig(os.path.join(a.out, f"{name}_m{m}_convergence.png"), dpi=150); plt.close()


if __name__ == "__main__":
    main()
