"""Batch run: every image in a folder x every level x N independent runs -> CSV.
python run_experiments.py data/images --levels 2 3 4 5 --runs 10"""
import argparse, glob, os, sys, time
import numpy as np, pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))
from rmce_chio import rmce_chio_threshold, apply_thresholds, psnr, ssim
from main import load_gray


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("--levels", type=int, nargs="+", default=[2, 3, 4, 5])
    ap.add_argument("--runs", type=int, default=10)
    ap.add_argument("--pop", type=int, default=30)
    ap.add_argument("--iters", type=int, default=100)
    ap.add_argument("--out", default="outputs/results.csv")
    a = ap.parse_args()

    files = sorted(sum([glob.glob(os.path.join(a.folder, e)) for e in ("*.jpg", "*.jpeg", "*.png", "*.bmp", "*.tif")], []))
    rows = []
    for f in files:
        gray = load_gray(f)
        for m in a.levels:
            for r in range(a.runs):
                t0 = time.time()
                T, obj, _ = rmce_chio_threshold(gray, m, hs=a.pop, max_itr=a.iters, seed=r)
                _, seg = apply_thresholds(gray, T)
                rows.append(dict(image=os.path.basename(f), m=m, run=r, thresholds=T.tolist(),
                                 objective=obj, psnr=psnr(gray, seg), ssim=ssim(gray, seg),
                                 time_s=time.time() - t0))
        print("done", f)
    df = pd.DataFrame(rows)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    df.to_csv(a.out, index=False)
    print(df.groupby(["image", "m"])[["objective", "psnr", "ssim", "time_s"]].agg(["mean", "std"]).round(4))


if __name__ == "__main__":
    main()
