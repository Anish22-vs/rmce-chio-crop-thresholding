function H = rmce_table(img)
% RMCE_TABLE  Recursive moment tables + class-cost lookup table for R-MCE.
% H(lo+1, hi+1) = cost of the class holding gray levels lo+1 .. hi  (levels 1..256)
L = 256;
h = histcounts(double(img(:)), -0.5:1:255.5) / numel(img);   % h(i) <-> intensity i-1
P = zeros(1, L+1);  S = zeros(1, L+1);
for u = 1:L                      % recursive computation
    P(u+1) = P(u) + h(u);
    S(u+1) = S(u) + u * h(u);
end
w = P - P';                      % w(lo+1,hi+1) = P(hi)-P(lo)
m = S - S';
H = -m .* log(m ./ w);
H(~isfinite(H)) = 0;
end
