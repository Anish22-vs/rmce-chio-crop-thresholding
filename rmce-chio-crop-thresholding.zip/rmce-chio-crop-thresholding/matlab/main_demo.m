% MAIN_DEMO  R-MCE + CHIO multilevel thresholding of one crop image.
clear; clc;
img = imread('../data/images/your_crop_image.jpg');   % <-- change file name
if size(img,3) == 3, img = rgb2gray(img); end
img = uint8(img);
levels = [2 3 4 5];
H = rmce_table(img);
for m = levels
    obj = @(x) rmce_objective(H, x);
    tic; [T, f, hist] = chio_optimize(obj, m, 0, 254, 30, 100); t = toc;
    seg = zeros(size(img), 'uint8');
    edges = [-1, T, 255];
    for k = 1:numel(edges)-1
        mask = img > edges(k) & img <= edges(k+1);
        if any(mask(:)), seg(mask) = uint8(mean(double(img(mask)))); end
    end
    fprintf('m=%d  T=%s  obj=%.4f  PSNR=%.2f  SSIM=%.4f  time=%.2fs\n', ...
        m, mat2str(T), f, psnr(seg, img), ssim(seg, img), t);
    figure; subplot(1,3,1); imshow(img); title('Original');
    subplot(1,3,2); imshow(seg); title(sprintf('Segmented m=%d', m));
    subplot(1,3,3); imhist(img); hold on; xline(T, 'r'); title('Histogram + thresholds');
end
