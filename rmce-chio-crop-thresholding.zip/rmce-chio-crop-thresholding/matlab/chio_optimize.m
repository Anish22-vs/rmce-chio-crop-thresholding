function [best, fbest, hist] = chio_optimize(obj, dim, lb, ub, HS, maxItr, C0, BRr, maxAge)
% CHIO_OPTIMIZE  Coronavirus Herd Immunity Optimizer (minimisation).
% status: 0 susceptible, 1 infected, 2 immune
if nargin < 5, HS = 30; end
if nargin < 6, maxItr = 100; end
if nargin < 7, C0 = 1; end
if nargin < 8, BRr = 0.05; end
if nargin < 9, maxAge = 100; end
pop = lb + (ub - lb) * rand(HS, dim);
fit = zeros(HS, 1);
for i = 1:HS, fit(i) = obj(pop(i,:)); end
status = zeros(HS, 1);  status(randperm(HS, C0)) = 1;
age = zeros(HS, 1);
hist = zeros(maxItr, 1);
for it = 1:maxItr
    for i = 1:HS
        new = pop(i,:);  isCorona = false;
        for j = 1:dim
            r = rand;
            if r < BRr/3
                g = find(status == 1);
                if ~isempty(g), c = g(randi(numel(g)));
                    new(j) = pop(i,j) + rand*(pop(i,j) - pop(c,j)); isCorona = true; end
            elseif r < 2*BRr/3
                g = find(status == 0);
                if ~isempty(g), c = g(randi(numel(g)));
                    new(j) = pop(i,j) + rand*(pop(i,j) - pop(c,j)); end
            elseif r < BRr
                g = find(status == 2);
                if ~isempty(g), [~, k] = min(fit(g)); c = g(k);
                    new(j) = pop(i,j) + rand*(pop(i,j) - pop(c,j)); end
            end
        end
        new = min(max(new, lb), ub);
        fn = obj(new);
        if fn < fit(i), pop(i,:) = new; fit(i) = fn; end
        mf = mean(fit);
        if status(i) == 0 && fit(i) > mf && isCorona
            status(i) = 1; age(i) = 1;
        elseif status(i) == 1 && fit(i) <= mf && isCorona
            status(i) = 2;
        end
        if status(i) == 1
            age(i) = age(i) + 1;
            if age(i) >= maxAge
                pop(i,:) = lb + (ub - lb) * rand(1, dim);
                fit(i) = obj(pop(i,:)); status(i) = 0; age(i) = 0;
            end
        end
    end
    hist(it) = min(fit);
end
[fbest, b] = min(fit);
best = sort(round(pop(b,:)));
end
