function f = rmce_objective(H, T)
% RMCE_OBJECTIVE  Cross-entropy objective for thresholds T (pixel intensities 0..254).
T = sort(round(T(:)'));
if any(T < 0) || any(T > 254), f = 1e9; return; end
if any(diff(T) == 0), f = 1e6; return; end
edges = [0, T + 1, 256];
f = 0;
for k = 1:numel(edges)-1
    f = f + H(edges(k)+1, edges(k+1)+1);
end
end
